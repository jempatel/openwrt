<?php
/*
 */

echo "<div class='container-fluid'><div class='alert-wrapper  text-center'>";
echo "<div class='alert alert-primary text-center' role='alert'>Logging in...";
echo "</div>";
            
echo "
<div class='jumbotron'>
  <p class='lead'>Please wait while Hotspot system authenticates your <br/>
            user credentials against our servers.</p>
  <hr class='my-4'>
  <p>This may take up to 30 seconds approximately.</p>
  
</div>
";

echo "</div></div>";
